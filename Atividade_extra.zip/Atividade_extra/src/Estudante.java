public class Estudante extends Pessoa {

    String matricula;
    double nota01, nota02;

    public Estudante (String nome, String cpf, String matricula, double nota01, double nota02) {
        super(nome, cpf);
        this.matricula = matricula;
        this.nota01 = nota01;
        this.nota02 = nota02;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public double getNota01() {
        return nota01;
    }

    public void setNota01(float nota01) {
        this.nota01 = nota01;
    }

    public double getNota02() {
        return nota02;
    }

    public void setNota02(float nota02) {
        this.nota02 = nota02;
    }

    public double media(){
        return (nota01 + nota02) / 2;
    }

    @Override
    public String toString() {
        return "Nome: " + getNome() + ", CPF: " + getCpf() + ", Matrícula: " + matricula + nota01 + ", Nota 2: " + nota02;
    }

    public String getEstudanteCSV() {
        return String.join(";", getNome(), getCpf(), matricula, Double.toString(nota01), Double.toString(nota02));
    }

    public void setEstudanteCSV(String linha) {
        String[] dados = linha.split(";");
        if (dados.length == 5) {
            setNome(dados[0]);
            setCpf(dados[1]);
            matricula = dados[2];
            nota01 = Double.parseDouble(dados[3]);
            nota02 = Double.parseDouble(dados[4]);
        } else {
            throw new IllegalArgumentException("Formato inválido para linha CSV de estudante.");
        }
    }


    



}
