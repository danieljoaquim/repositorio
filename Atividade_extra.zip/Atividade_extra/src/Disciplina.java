import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Disciplina {



    private List<Estudante> minhaLista;

    public Disciplina() {
        minhaLista = new ArrayList<>();
    }

    public void addEstudante(Estudante estudante) {
        minhaLista.add(estudante);
    }

    public List<Estudante> getEstudantes() {
        return minhaLista;
    }

    public void insereEstudante(Scanner sc ){

        System.out.println("===============");
        System.out.println("Digite o nome do estudante:");
        sc.nextLine();
        String nome = sc.nextLine();

        System.out.println("Informe o número de matrícula:");
        String matricula = sc.nextLine();
        
        System.out.println("Informe o CPF do estudante:");
        String cpf = sc.nextLine();

        System.out.println("Informe a primeira nota:");
        int nota01 = sc.nextInt();

        System.out.println("Informe a segunda nota:");
        int nota02 = sc.nextInt();
        System.out.println("===============");


            Estudante estudante = new Estudante(nome, cpf, matricula, nota01, nota02);
        minhaLista.add(estudante);
    }

    public void salvaDados() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("estudantes.csv"))) {
            for (Estudante estudante : minhaLista) {
                bw.write(estudante.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Ocorreu um erro ao salvar os dados.");
            e.printStackTrace();
        }
    }



    public void alteraEstudante(Scanner sc) {
        System.out.println("===============");

        System.out.println("Qual o estudante você deseja alterar? Informe a matrícula.");
        sc.nextLine();
        String matricula = sc.nextLine();

        for (Estudante elemento : minhaLista){
            if (elemento.getMatricula().equals(matricula)) {
                
                System.out.println("Nome:" + elemento.getNome());
                
                System.out.println("Nova nota 1:");
                
                float novaNota01 = sc.nextFloat();
                elemento.setNota01(novaNota01);
                
                System.out.println("Nova nota 2: ");
                
                float novaNota02 = sc.nextFloat();
                elemento.setNota02(novaNota02);
                
                System.out.println("Média das novas notas:" + elemento.media());
                System.out.println("===============");

            }
        }
    }

    public void removeEstudante (Scanner sc){
        System.out.println("===============");

        System.out.println("Qual o estudante você deseja remover? Informe a matrícula.");
        sc.nextLine();
        String matricula = sc.nextLine();

     if (minhaLista.removeIf(estudante -> estudante.getMatricula().equals(matricula))) {
        System.out.println("Cadastro excluído!");
        System.out.println("===============");

    }    
    }

    public void consultaEstudante (Scanner sc) {
        System.out.println("===============");


        System.out.println("Qual estudante você deseja consultar?");
        sc.nextLine();
        String matricula = sc.nextLine();

        for (Estudante elemento : minhaLista) {
            if (elemento.getMatricula().equals(matricula)) {
                System.out.println("Nome: " + elemento.getNome());
                System.out.println("Matrícula:" + elemento.getMatricula());
                System.out.println("Nota 1: " + elemento.getNota01());
                System.out.println("Nota 2: " + elemento.getNota02());
                System.out.println("Média: " + elemento.media());
            }
        }
        System.out.println("===============");

    }


    public void listarEstudantes (Scanner sc) {
        System.out.println("===============");

        System.out.println("Lista de estudantes:");
        System.out.println();

        for (Estudante elemento : minhaLista) {
          
            System.out.println("Nome: " + elemento.getNome());
            System.out.println("Matrícula:" + elemento.getMatricula());
            System.out.println("Nota 1: " + elemento.getNota01());
            System.out.println("Nota 2: " + elemento.getNota02());
            System.out.println("Média: " + elemento.media());
            System.out.println("----------------------");
        }
        System.out.println("===============");

    }
    

    public void estudantesAbaixoMedia() {
        System.out.println("===============");

     for (Estudante elemento : minhaLista) {
        if (elemento.media() < 6) {
            System.out.println("Nome: " + elemento.getNome());
            System.out.println("Matrícula:" + elemento.getMatricula());
            System.out.println("Nota 1: " + elemento.getNota01());
            System.out.println("Nota 2: " + elemento.getNota02());
            System.out.println("Média: " + elemento.media());
            System.out.println("----------------");

        }
        System.out.println("===============");

     }       
    }

    public void estudantesAcimaMedia() {
        System.out.println("===============");

        for (Estudante elemento : minhaLista) {
           if (elemento.media() > 6 || elemento.media() == 6)  {
               System.out.println("Nome: " + elemento.getNome());
               System.out.println("Matrícula:" + elemento.getMatricula());
               System.out.println("Nota 1: " + elemento.getNota01());
               System.out.println("Nota 2: " + elemento.getNota02());
               System.out.println("Média: " + elemento.media());
               System.out.println("-----------------");
           }
        }       
        System.out.println("===============");

       }

    public void mediaDaTurma (){
        System.out.println("===============");

        double mediaTurma = 0;
        int indice = 0;
        for (Estudante elemento : minhaLista) {
        mediaTurma = mediaTurma + elemento.media();
        indice = minhaLista.size();
        }
        double media = mediaTurma/indice;
        System.out.println("Média da turma: " + media);
        System.out.println("===============");

    }
    // Carrega os dados do arquivo
    public void carregaDados() {
        try (BufferedReader br = new BufferedReader(new FileReader("estudantes.csv"))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                Estudante estudante = new Estudante("", "", "", 0.0, 0.0);
                estudante.setEstudanteCSV(linha);
                minhaLista.add(estudante);
            }
        } catch (IOException e) {
            System.err.println("Erro ao carregar dados dos estudantes do arquivo.");
        }
    }

    // Grava os dados no arquivo
    public void salvar() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("estudantes.csv"))) {
            for (Estudante estudante : minhaLista) {
                bw.write(estudante.getEstudanteCSV());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao gravar dados.");
        }
    }

   
}

  





