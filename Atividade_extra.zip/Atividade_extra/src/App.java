
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        Disciplina d1 = new Disciplina();
        
        int opcao = 0;
        d1.carregaDados();

        while (opcao != 9) {
            System.out.println("Digite um número");
            System.out.println("Digite 1 para adicionar um estudante;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 2 para listar os estudantes da matéria;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 3 para alterar as notas de uum estudante;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 4 para consultar informações de um estudante;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 5 para mostrar os estudantes com média abaixo de 6");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 6 para mostrar os estudantes com média igual ou superior a 6;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 7 para mostrar a média da turma;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 8 para excluir o cadastro de um estudante;");
            System.out.println("--------------------------------------------------------------------");
            System.out.println("Digite 9 para sair");

            opcao = sc.nextInt();
        

        switch (opcao) {
            case 1:
                d1.insereEstudante(sc);
                break;
            case 2:
                d1.listarEstudantes(sc);
                break;
            case 3: 
                d1.alteraEstudante(sc);
                break;
            case 4: 
                d1.consultaEstudante(sc);
                break;
            case 5:
                d1.estudantesAbaixoMedia();
                break;
            case 6:
                d1.estudantesAcimaMedia();
                break;
            case 7:
                d1.mediaDaTurma();
                break;
            case 8: 
                d1.removeEstudante(sc);
                break;
            case 9:
                d1.salvar();
                break;

            default:
                System.out.println("Opção inválida!");
                break;
        }
    }
        

        sc.close();
    }
}
